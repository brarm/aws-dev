
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.17.2'
version = '1.17.2'
full_version = '1.17.2'
git_revision = 'fce34f559f17674e7a3301c46b0a9cc991c143d4'
release = True

if not release:
    version = full_version
